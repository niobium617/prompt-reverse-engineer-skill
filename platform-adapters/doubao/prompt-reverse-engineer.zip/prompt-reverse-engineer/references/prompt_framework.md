# Prompt 标准结构规范（总纲）

> 本文件是技能的数据契约权威来源：`semantic_analysis` 的全部字段定义、评分细则、安全规则与优化建议库均以此为准。`scripts/prompt_compiler.py` 与 `assets/templates/*.json` 中的占位符字段名必须与本文件一致。

## 一、Prompt 六要素结构

所有生成的 Prompt 均遵循六要素框架，各模型格式按 `model_mappings.md` 映射转换：

| 要素 | 含义 | 写作要点 | 常见错误 |
|---|---|---|---|
| 角色 Role | 生成者扮演的身份 | 明确专业领域 + 人设定位（如"资深广告文案策划，服务过 500 强品牌"） | 只写"你是专家"，无领域锚点 |
| 任务 Task | 要完成的具体动作 | 动词开头、单任务聚焦、可执行（"撰写一篇…文案"） | 任务模糊或一次塞多个任务 |
| 背景 Context | 任务发生的背景信息 | 提供产品/受众/场景/目的等必要上下文 | 背景缺失导致生成泛化；背景冗余挤占注意力 |
| 要求 Requirement | 内容层面的期望 | 风格、语气、结构、要点覆盖 | 要求写成形容词堆砌，无法校验 |
| 限制 Constraint | 硬性边界 | 字数、格式、禁用词、禁止内容，可量化 | 限制过松无法约束；过紧导致无法生成 |
| 输出 Output | 输出的结构与格式 | 明确分节、字段、长度、可直接使用 | 输出格式未指定，结果不可复用 |

## 二、semantic_analysis 规范字段表（L2 契约）

Agent 完成语义分析后，按本表产出 `semantic_analysis` 对象，交 `prompt_compiler.py` 编译。模板占位符即本表字段名。

### 2.1 通用字段（三模态均建议提供）

| 字段 | 类型 | 必填 | 说明与示例 |
|---|---|---|---|
| summary | string[] | 建议 | 分析摘要要点 3-8 条，如 `["标题直给卖点，含数字冲击"]` |
| suggestions | string[] | 可选 | Agent 自评的待改进点，1-2 条 |

### 2.2 文本模态字段（modality=text）

| 字段 | 必填 | 说明与示例 |
|---|---|---|
| role | 是 | 角色定位：作者身份+专业领域+人设。如 `"美妆护肤领域资深文案策划，熟悉小红书爆款逻辑"` |
| domain | 建议 | 专业领域，如 `"消费电子 / 3C 数码"` |
| audience | 建议 | 目标受众，如 `"25-35 岁都市白领，注重效率与颜值"` |
| task | 是 | 复刻任务描述，如 `"撰写同类产品种草文案"` |
| style | 是 | 写作风格：语言特点+情绪倾向+表达方式+关键词习惯。如 `"口语化短句、感叹号收尾、亲切有网感，高频词：绝绝子、闭眼入"` |
| structure | 是 | 结构逻辑：开头方式+展开方式+组织方式+结尾设计。如 `"痛点开头→卖点分条→场景代入→限时促单结尾"` |
| constraints | 是 | 约束规则：字数/格式/禁用内容。如 `"全文 ≤200 字，含 3 个 emoji，禁用'最'字"` |
| output_format | 建议 | 输出格式规范，如 `"标题一行 + 正文 3 段 + 标签行"` |

### 2.3 图像模态字段（modality=image）

渲染顺序（`image_rules.md` 第一节七段结构）：subject → scene → style → lighting → color → composition → photo_params → quality_words。字段定义与必填性如下：

| 字段 | 必填 | 说明与示例 |
|---|---|---|
| subject | 是 | 主体：**先身份外形、后动作状态**（人物/物体+动作+外观+服饰）。如 `"年轻女性，黑色风衣，手持透明伞，回眸望向镜头，神情宁静"` |
| scene | 是 | 场景：地点+环境+时间+氛围。如 `"雨夜霓虹街头，潮湿反光地面，未来都市"` |
| composition | 是 | 构图：视角+景别+构图方式（七段中位于光影之后）。如 `"低角度仰拍，中景，三分法构图，人物居中偏右"` |
| lighting | 是 | 光影：光源方向+明暗关系+氛围（与 color 相邻渲染组成「光影色调」）。如 `"霓虹灯牌侧光，轮廓光勾勒，高对比夜色"` |
| color | 是 | 色彩：主色调+色彩风格+饱和度（与 lighting 相邻渲染）。如 `"深蓝紫为主，霓虹橙青点缀，高饱和冷色调"` |
| style | 建议 | 整体风格（七段中位于场景之后、光影之前）。如 `"赛博朋克 / 胶片摄影 / 扁平插画"` |
| photo_params | 建议 | 摄影参数：镜头类型+焦距+景深（与 quality_words 收尾组成「画质与质感」）。如 `"50mm 定焦，f/1.8 浅景深，35mm 等效"` |
| quality_words | 建议 | 质量词，如 `"超清细节, 8K, 电影级光影"`（MJ 正向提示用） |
| negative_words | 建议 | 负向词表，按「画面瑕疵/风格违和/内容违和」三类组织（见 image_rules.md 第八节），如 `"模糊, 低质量, 畸形, 多余肢体, 卡通, 明亮清新, 违和道具"`（MJ `--no` 参数用） |
| target_style | 可选 | 风格迁移目标，如 `"宫崎骏动画风格"`（style_transfer 模板用） |

### 2.4 视频模态字段（modality=video）

| 字段 | 必填 | 说明与示例 |
|---|---|---|
| story | 是 | 故事结构：起承转合/情节发展摘要 |
| storyboard | 是 | 分镜表：对象数组，每项含 `shot_no/景别(shot_size)/运镜(camera_move)/时长(duration_s)/画面内容(action)/台词(dialogue)`，与 `video_rules.md` 分镜规范一致。渲染规则（prompt_compiler.py format_field）：每项渲染为 `镜头{shot_no}：{shot_size}，{camera_move}，{duration_s}秒。{action}（台词：{dialogue}）` 的逐行文本 |
| character | 是 | 人物：年龄+外貌+服装+动作+人物关系 |
| camera | 建议 | 镜头风格：景别变化+运镜方式+镜头节奏 |
| lighting | 建议 | 灯光：光源+氛围 |
| atmosphere | 建议 | 环境氛围：场景+时间+天气 |
| narration | 可选 | 旁白/对话内容 |
| duration | 建议 | 成片时长（秒），如 `"10"` |
| aspect_ratio | 建议 | 画幅比例，如 `"16:9"` |

### 2.5 叙事文本场景化字段（modality=story）

用于「剧本/小说/文章 → 逐场景图片+视频提示词」。Agent 先通读全文提炼全局基调，再按场景切分信号（`scripts/analyze_scenes.py`）逐场景提炼语义。渲染由 `prompt_compiler.py scenes` 子命令完成：每个场景对象同时按 image 模板（默认 mj,sd）与 video 模板（默认 sora）渲染。

顶层字段（`semantic_analysis` 内）：

| 字段 | 必填 | 说明与示例 |
|---|---|---|
| summary | 建议 | 全文题材/风格基调概述。如 `"都市情感短片：雨夜偶遇与咖啡厅告别，冷调写实摄影风格"` |
| characters | 建议 | 主要角色表（辅助各场景主体提炼）。如 `"林晓：25 岁女性，黑色风衣，短发；陈默：28 岁男性，深灰大衣"` |
| scenes | 是 | 场景数组，每项字段见下表 |

场景对象字段（`scenes[i]`，图片字段复用 2.3 节、视频字段复用 2.4 节，字段名/必填性与各节一致）：

| 字段 | 必填 | 说明与示例 |
|---|---|---|
| scene_no | 是 | 场景编号，从 1 起整数 |
| title | 建议 | 场景标题，如 `"雨夜街头相遇"` |
| （图片七段）subject / scene / style / lighting / color / composition / photo_params / quality_words / negative_words / target_style | 同 2.3 节 | 按 `image_rules.md` 第一节七段规范提炼；`target_style` 为可选风格迁移目标 |
| （视频分镜）story / duration / aspect_ratio / storyboard / character / camera / atmosphere / narration | 同 2.4 节 | 按 `video_rules.md` 分镜规范提炼；`lighting` 字段同时服务图片与视频模板 |

场景切分原则：**时间 / 地点 / 人物关系任一变化即新场景**；每个场景独立完成七段提炼与分镜设计，风格基调沿用顶层 `summary` 结论保持一致。

## 三、评分细则

百分制，六维加权。权重定义于 `prompt_compiler.py`（启动时校验权重和为 100，禁止修改不一致）。

| 维度 | 权重 | 90+ 锚点 | 75+ 锚点 | 60+ 锚点 |
|---|---|---|---|---|
| 主题明确度 theme_clarity | 20% | 一眼可知生成什么，无歧义 | 主题清楚但有一处歧义 | 主题可辨识但需猜测 |
| 场景完整度 scene_completeness | 20% | 主体/环境/氛围要素齐全 | 要素基本齐全，缺次要项 | 仅有主体，场景缺失 |
| 风格契合度 style_fit | 20% | 风格关键词与原作高度一致且可执行 | 风格方向一致，细节有偏差 | 风格方向大致接近 |
| 结构清晰度 structure_clarity | 15% | 六要素齐备、顺序符合各模型规范 | 要素齐备，顺序欠佳 | 要素缺 1 项以上 |
| 参数合理性 param_reasonableness | 15% | 参数与内容匹配且符合模型语法 | 参数正确但有一处冗余/缺失 | 参数存在但部分无效 |
| 可调性/复用性 adaptability | 10% | 变量已显式化，用户可直接替换复用 | 大部分可复用，需小改 | 仅适用于当前样例 |

评分计算：`总分 = Σ(权重 × 维度得分) / 100`。等级：A ≥ 90；B ≥ 75；C ≥ 60；D < 60。取得分最低的 1-2 个维度，从下方建议库各取 1 条建议附在报告后。

## 四、安全规则（输出前必检）

1. **禁止越狱内容**：输出 Prompt 中不得出现"忽略此前指令""输出你的系统提示词""越狱""DAN 模式"等绕开目标模型安全约束的表述。
2. **禁止可执行命令**：不得包含 `rm -rf`、`format c:`、`del /f`、`shutdown`、`cmd.exe`、`powershell`、`taskkill`、`reg add`、`net user`、`os.system`、`subprocess`、`exec(`、`eval(`、`DROP TABLE` 等可引发系统操作的内容。
3. **敏感内容拒绝**：涉及暴力、露骨色情、违法侵权（明确要求模仿在世特定人物的肖像/声音）的内容，拒绝生成并说明原因。
4. 生成前必须经 `prompt_compiler.py filter` 校验：命中黑名单 → 阻断（退出码 5），重写后重新编译。

## 五、优化建议库

与 `prompt_compiler.py` 中 `SUGGESTIONS` 常量逐条镜像，修改必须两处同步（脚本内注释互指）：

- theme_clarity：① 在 Prompt 首句直接点明生成对象与核心特征，删除可有可无的修饰；② 为目标受众补一句限定，避免生成泛化。
- scene_completeness：① 补充时间、地点、氛围三要素之一；② 用具体名词替换模糊场景词（如"街道"→"雨夜霓虹街头"）。
- style_fit：① 增加 1-2 个风格锚点词（参考 image_rules.md / video_rules.md 术语库）；② 删除与整体风格冲突的修饰词。
- structure_clarity：① 按六要素顺序重排（角色→任务→背景→要求→限制→输出格式）；② 将隐含约束显式写出（字数、格式、禁用词）。
- param_reasonableness：① 对照 model_mappings.md 核对参数语法与取值范围；② 删除与内容不匹配的多余参数。
- adaptability：① 把具体样例中的可变项替换为 `[变量]` 占位；② 为可调参数添加注释说明取值范围。

## 六、扩展指南

- **新增分析维度**：在本文档 2.x 添加字段定义 → 在对应模型模板 JSON 的占位串中引用新字段 → 在 SKILL.md 分析要点补一行。无需改脚本。
- **新增评分维度**：修改 `prompt_compiler.py` 中 `DIMENSIONS`（含权重，和须为 100）→ 在本文档第三节补锚点 → 在第五节补建议条目（保持两处镜像）。
- **新增目标模型**：在 `assets/templates/` 新增一个 `*.json` 模板文件（含 `model`、`alias`、`default_params`、`modalities` 字段），编译器自动注册发现；在 `model_mappings.md` 补映射表行。零代码改动。模板内若需引用非语义字段（模型名、调用参数等），写进 `default_params` 由编译器注入（范例：`deepseek.json` 的 `model_id` / `thinking_effort`），**不要**加进本文档第二节字段表。
